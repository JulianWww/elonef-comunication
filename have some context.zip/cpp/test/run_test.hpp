#pragma once

void test_aes();
void test_ecdsa();
void test_encoding();
void test_error();
void test_rsa();