mkdir tmp
cd tmp

