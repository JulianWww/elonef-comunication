#include <iostream>

int main(int, char**){
    std::cout << "Hello, from t!\n";
}
